/* 
 * Simple Node Class to act as a Singly Linked List. 
 */


public class Node
{
    char data;
    Node next;

    public Node(char c)
    {
        data = c;
        next = null;
    }

}
